<template>
  <h2>购物车</h2>
</template>

<script>
  export default {
    name: "Cart"
  }
</script>

<style scoped>

</style>
