<template>
  <h2>个人</h2>
</template>

<script>
  export default {
    name: "Profile"
  }
</script>

<style scoped>

</style>
